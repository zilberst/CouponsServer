package com.jesus.coupons.enums;

public enum MartialStatus {
	
	SINGLE,
	MARRIED,
	OTHER

}
