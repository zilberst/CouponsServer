package com.jesus.coupons.enums;

public enum CouponCategories {
	
	A,
	B
}
