package com.jesus.coupons.enums;

public enum CompanyTypes {

	A,
	B
}
