package com.jesus.coupons.enums;

public enum UserTypes {
	
	ADMIN,
	COMPANY,
	CUSTOMER,
}
