export class Coupon{
    public constructor(
        public id?:number,
        public title?:string,
        public remainingStock?:number,
        public price?:number,
        public startDate?:string,
        public expiryDate?:string,
        public category?:string,
        public description?:string
    ){}

}