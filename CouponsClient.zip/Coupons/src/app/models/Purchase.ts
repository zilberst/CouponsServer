import { Coupon } from './Coupon';

export class Purchase{
    public constructor(
        public coupon?:Coupon,
        public amountOfItems?:number,
        public totalPrice?: number,
        public timestamp?: string
    ){}

}