import { User } from './User';

export class Customer{
    public constructor(
        public amountOfKids?:number,
        public martialStatus?:string,
        public address?:string,
        public user?:User
    ){}

}