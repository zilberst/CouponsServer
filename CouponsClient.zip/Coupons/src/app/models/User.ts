export class User{
    public constructor(
        public firstName?:string,
        public lastName?:String,
        public eMail?:string,
        public username?:string,
        public password?:string
    ){}

}