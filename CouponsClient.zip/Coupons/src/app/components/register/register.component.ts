import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/models/Customer';
import { User } from 'src/app/models/User';
import { Router } from '@angular/router';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  public customer: Customer; 
  public errorMessage: string;
  public customerService: CustomerService;
  public router: Router;

  constructor(router: Router, customerService: CustomerService) {
    this.router = router;
    this.customerService = customerService;
    this.customer = new Customer(0, "", "", new User("", "", "", "", ""));
    this.errorMessage = "";
   }

  ngOnInit() {
    
  }

  public register() : void {
    if (this.fieldsAreEmpty()) {
      this.errorMessage = "All fields must be filled";
      return;
    }
    let observable = this.customerService.register(this.customer);

    observable.subscribe(observable => {
      console.log("Registered successfully");
      this.errorMessage = "";
      this.router.navigate(["/home"]);
    }, ErrorHandler => {
      this.errorMessage = ErrorHandler.error.errorMessage;
      console.log(ErrorHandler); 
    })
  }

  public showLogin() : void {
    this.router.navigate(["/home"]);
  }

  private fieldsAreEmpty(): boolean {
    if (this.customer.user.firstName == "" ||
        this.customer.user.lastName == "" ||
        this.customer.user.eMail == "" ||
        this.customer.user.username == "" ||
        this.customer.user.password == "" ||
        this.customer.martialStatus == "" ||
        this.customer.address == "") {
          return true;
        }
    return false;
  }

}
