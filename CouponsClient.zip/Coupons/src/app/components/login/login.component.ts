import { Component, OnInit } from '@angular/core';
import { UserLoginDetails } from '../../models/UserLoginDetails';
import { UserService } from 'src/app/services/users.service';
import { Router, PRIMARY_OUTLET } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public userLoginDetails: UserLoginDetails;
  public errorMessage: string;

  constructor(public userService?: UserService, public router?: Router) { 
    this.userLoginDetails = new UserLoginDetails("", "");
    this.errorMessage = "";
  }

  ngOnInit() {
  }

  public login() : void {
    
    let observable = this.userService.login(this.userLoginDetails);

    observable.subscribe(successfulServerRequestData => {
      console.log(successfulServerRequestData);
      sessionStorage.setItem("token", successfulServerRequestData.token+"");
      sessionStorage.setItem("firstName", successfulServerRequestData.firstName+"");
      sessionStorage.setItem("lastName", successfulServerRequestData.lastName+"");
      this.router.navigate(["/customer"]);
    }, ErrorHandler => {
      this.errorMessage = ErrorHandler.error.errorMessage;
      console.log(ErrorHandler); 
    })

  }

  public showRegister() : void {
    this.router.navigate(["/register"]);
  }

}
