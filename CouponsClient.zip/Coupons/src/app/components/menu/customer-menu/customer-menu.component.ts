import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-menu',
  templateUrl: './customer-menu.component.html',
  styleUrls: ['./customer-menu.component.css']
})
export class CustomerMenuComponent implements OnInit {

  public errorMessage: string;

  constructor(public router?: Router) {
    this.errorMessage = "";
  }

  ngOnInit() {
  }

  public showMyPurchases() {
    this.router.navigate(["/customer/myPurchases"]);
  }

  public showCoupons() {
    this.router.navigate(["/customer/availableCoupons"]);
  }

  public showMyDetails() {
    this.router.navigate(["/customer/myDetails"]);
  }

  public showCustomerHome() {
    this.router.navigate(["/customer"]);
  }

  public logout() {
    sessionStorage.clear();
    this.router.navigate(["/home"]);
  }
}
