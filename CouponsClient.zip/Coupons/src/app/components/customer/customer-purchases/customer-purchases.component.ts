import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PurchaseService } from 'src/app/services/purchase.service';
import { Purchase } from 'src/app/models/Purchase';
import { CouponService } from 'src/app/services/coupon.service';
import { Coupon } from 'src/app/models/Coupon';

@Component({
  selector: 'app-customer-purchases',
  templateUrl: './customer-purchases.component.html',
  styleUrls: ['./customer-purchases.component.css']
})
export class CustomerPurchasesComponent implements OnInit {
  
  public errorMessage: string;
  public purchases: Purchase[];
  public minSum: number;
  public maxSum: number;
  public displayedCoupon: Coupon;

  constructor(public router?: Router, public purchaseService?: PurchaseService, public couponService?: CouponService) {
    this.errorMessage = "";
    this.purchases = [];
    this.minSum = 0;
    this.maxSum = 999999;
    this.displayedCoupon = new Coupon();
  }

  ngOnInit() {
    let observable = this.purchaseService.getMyPurchases();
    observable.subscribe(purchaseList => {
      this.purchases = purchaseList;
    },  ErrorHandler => {
      console.log(ErrorHandler);
      this.router.navigate(["/customer"]);
    });
  }

  public onPurchaseClicked(currentPurchase: Purchase) {
    let observable = this.couponService.getCouponById(currentPurchase.coupon.id);
    observable.subscribe(coupon => {
      this.displayedCoupon = coupon;
    },  ErrorHandler => {
      this.errorMessage = ErrorHandler.error.errorMessage;
      console.log(ErrorHandler);
    });
  }

  public onCancelClicked():void{
    // this.displayedCoupon = null;
  }

  public showCustomerHome() {
    this.router.navigate(["/customer"]);
  }

}
