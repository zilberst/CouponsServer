import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/models/Customer';
import { User } from 'src/app/models/User';

@Component({
  selector: 'app-customer-home',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerHomeComponent implements OnInit {

  public firstName: string;
  public lastName: string;
  public errorMessage: string;

  constructor(public router?: Router) {
    this.firstName = "";
    this.lastName = "";
    this.errorMessage = "";
  }

  ngOnInit() {
    this.firstName = sessionStorage.getItem("firstName");
    this.lastName = sessionStorage.getItem("lastName");
  }

  public showMyPurchases() {
    this.router.navigate(["/customer/myPurchases"]);
  }

  public showCoupons() {
    this.router.navigate(["/customer/availableCoupons"]);
  }

  public showMyDetails() {
    this.router.navigate(["/customer/myDetails"]);
  }

  public logout() {
    this.router.navigate(["/home"]);
  }

}
