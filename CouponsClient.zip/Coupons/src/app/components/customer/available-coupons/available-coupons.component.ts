import { Component, OnInit } from '@angular/core';
import { Coupon } from 'src/app/models/Coupon';
import { PurchaseService } from 'src/app/services/purchase.service';
import { Purchase } from 'src/app/models/Purchase';
import { Router } from '@angular/router';
import { CouponService } from 'src/app/services/coupon.service';

@Component({
  selector: 'app-available-coupons',
  templateUrl: './available-coupons.component.html',
  styleUrls: ['./available-coupons.component.css']
})
export class AvailableCouponsComponent implements OnInit {

  public coupons: Coupon[];
  public displayedCoupon: Coupon;
  public maxPrice: number;
  public minPrice: number;
  public amountToBuy: number;
  public purchase: Purchase;
  public errorMessage: string;

  constructor(public router?: Router, public purchaseService?: PurchaseService, public couponService?: CouponService) {
    this.displayedCoupon = new Coupon();
    this.coupons = [];
    this.minPrice = 0;
    this.maxPrice = 99999;
    this.amountToBuy = 0;
    this.purchase = new Purchase();
    this.errorMessage = "";
   }

  ngOnInit() {
    let observable = this.couponService.getAllCoupons();
    observable.subscribe(couponsList => {
      this.coupons = couponsList;
    }, ErrorHandler => {
      console.log(ErrorHandler);
      this.router.navigate(["/customer"]);
    });
  }

  public purchaseCoupon() {

    this.purchase.amountOfItems = this.amountToBuy;
    this.purchase.coupon = new Coupon();
    this.purchase.coupon.id = this.displayedCoupon.id;
    let observable = this.purchaseService.purchaseCoupon(this.purchase);

    observable.subscribe(Observable => {
      console.log("Purchased successfully");
    }, ErrorHandler => {
      this.errorMessage = ErrorHandler.error.errorMessage;
      console.log(ErrorHandler);
    })
  }

  public onCouponClicked(currentCoupon:Coupon):void{
    this.displayedCoupon = currentCoupon;
  }

  public onCancelClicked():void{
    // this.displayedCoupon = null;
  }

  public showCustomerHome() {
    this.router.navigate(["/customer"]);
  }

}
