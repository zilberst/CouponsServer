import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from 'src/app/models/Customer';
import { CustomerService } from 'src/app/services/customer.service';
import { User } from 'src/app/models/User';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {
  
  public customerDetails: Customer;
  public errorMessage: string;

  constructor(public router?: Router, public customerService?: CustomerService) {
    this.customerDetails = new Customer(0, "", "", new User("", "", "", "", ""));
    this.errorMessage = "";
   }

  ngOnInit() {
    
    let observable = this.customerService.getMyDetails();
    
    observable.subscribe(customerDetails => {
      customerDetails.user.password = "";
      this.customerDetails = customerDetails;
    },  ErrorHandler => {
      console.log(ErrorHandler);
      this.router.navigate(["/customer"]);
    });
  }

  public editCustomerDetails() {
    if (this.fieldsAreEmpty()) {
      this.errorMessage = "All fields must be filled";
      return;
    }
    let observable = this.customerService.updateCustomer(this.customerDetails);
    
    observable.subscribe(Observable => {
      console.log("Details updated successfully");
      this.router.navigate(["/customer"]);
    },  ErrorHandler => {
      this.errorMessage = ErrorHandler.error.errorMessage;
      console.log(ErrorHandler);
    });
  }

  public showCustomerHome() {
    this.router.navigate(["/customer"]);
  }

  private fieldsAreEmpty(): boolean {
    if (this.customerDetails.user.firstName == "" ||
        this.customerDetails.user.lastName == "" ||
        this.customerDetails.user.eMail == "" ||
        this.customerDetails.user.username == "" ||
        this.customerDetails.user.password == "" ||
        this.customerDetails.martialStatus == "" ||
        this.customerDetails.address == "") {
          return true;
        }
    return false;
  }

}
