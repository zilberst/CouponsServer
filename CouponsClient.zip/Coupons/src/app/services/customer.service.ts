import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Purchase } from '../models/Purchase';
import { Customer } from '../models/Customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private httpClient: HttpClient) {}

  public getAllCoupons(): Observable<Purchase[]> {
      return this.httpClient.get<Purchase[]>("http://localhost:8080/purchases/getMyPurchases");
  }

  public register(customer : Customer): Observable<void> {
    return this.httpClient.post<void>("http://localhost:8080/customers", customer);
  }

  public getMyDetails(): Observable<Customer> {
    return this.httpClient.get<Customer>("http://localhost:8080/customers/getMyDetails");
  }

  public updateCustomer(customer: Customer): Observable<void> {
    return this.httpClient.put<void>("http://localhost:8080/customers", customer);
  }
}
