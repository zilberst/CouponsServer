import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Coupon } from '../models/Coupon';

@Injectable({
  providedIn: 'root'
})

export class CouponService {
 
  constructor(private httpClient: HttpClient) {}

  public getCouponById(couponId: number): Observable<Coupon> {
    return this.httpClient.get<Coupon>("http://localhost:8080/coupons/" + couponId);
  }

  public getAllCoupons(): Observable<Coupon[]> {
      return this.httpClient.get<Coupon[]>("http://localhost:8080/coupons");
  }
}
