import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserLoginDetails } from '../models/UserLoginDetails';
import { SuccessfulLoginServerResponse } from '../models/SuccessfulLoginServerResponse';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient:HttpClient){
    this.httpClient = httpClient;
  }

  public login(userLoginDetails : UserLoginDetails): Observable<SuccessfulLoginServerResponse> {
    return this.httpClient.post<SuccessfulLoginServerResponse>("http://localhost:8080/users/login", userLoginDetails);
  }

}
