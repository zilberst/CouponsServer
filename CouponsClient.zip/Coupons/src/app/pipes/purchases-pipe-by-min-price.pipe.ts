import { Pipe, PipeTransform } from '@angular/core';
import { Purchase } from '../models/Purchase';

@Pipe({
  name: 'purchasesMinSumPipe'
})
export class PurchasesPipeByMinSumPipe implements PipeTransform {

  transform(purchases: Purchase[], minSum: number): any {
    return purchases.filter(purchase => purchase.totalPrice >= minSum);
  }

}
