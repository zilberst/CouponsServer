import { Pipe, PipeTransform } from '@angular/core';
import { Coupon } from '../models/Coupon';

@Pipe({
  name: 'couponsMaxPricePipe'
})
export class CouponsPipeByMaxPricePipe implements PipeTransform {

  transform(coupons: Coupon[], maxPrice: number): any {
    return coupons.filter(coupon => coupon.price <= maxPrice);
  }

}
