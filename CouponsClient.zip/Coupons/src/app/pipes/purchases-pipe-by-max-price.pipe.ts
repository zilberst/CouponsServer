import { Pipe, PipeTransform } from '@angular/core';
import { Purchase } from '../models/Purchase';

@Pipe({
  name: 'purchasesMaxSumPipe'
})
export class PurchasesPipeByMaxSumPipe implements PipeTransform {

  transform(purchases: Purchase[], maxSum: number): any {
    return purchases.filter(purchase => purchase.totalPrice <= maxSum);
  }

}
