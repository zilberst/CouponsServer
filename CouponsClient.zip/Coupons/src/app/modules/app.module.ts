import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_BOOTSTRAP_LISTENER } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { RoutingModule } from './routing.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { LayoutComponent } from '../components/layout/layout.component';
import { HeaderComponent } from '../components/header/header.component';
import { FooterComponent } from '../components/footer/footer.component';
import { UserService } from '../services/users.service';
import { AuthenticationInterceptor } from '../interceptors/AuthenticationInterceptor';
import { CouponService } from '../services/coupon.service';
import { CouponsPipeByMinPricePipe } from '../pipes/coupons-pipe-by-min-price.pipe';
import { PurchaseService } from '../services/purchase.service';
import { CustomerService } from '../services/customer.service';
import { LoginComponent } from '../components/login/login.component';
import { RegisterComponent } from '../components/register/register.component';
import { CustomerPurchasesComponent } from '../components/customer/customer-purchases/customer-purchases.component';
import { AvailableCouponsComponent } from '../components/customer/available-coupons/available-coupons.component';
import { CustomerHomeComponent } from '../components/customer/customer-home/customer.component';
import { CustomerDetailsComponent } from '../components/customer/customer-details/customer-details.component';
import { CustomerMenuComponent } from '../components/menu/customer-menu/customer-menu.component';
import { CouponsPipeByMaxPricePipe } from '../pipes/coupons-pipe-by-max-price.pipe';
import { PurchasesPipeByMaxSumPipe } from '../pipes/purchases-pipe-by-max-price.pipe';
import { PurchasesPipeByMinSumPipe } from '../pipes/purchases-pipe-by-min-price.pipe';

@NgModule({
  declarations: [
  LayoutComponent,   
  HeaderComponent,   
  FooterComponent,
  LoginComponent,
  CustomerHomeComponent,
  CouponsPipeByMinPricePipe,
  LoginComponent,
  RegisterComponent,
  CustomerPurchasesComponent,
  AvailableCouponsComponent,
  CustomerDetailsComponent,
  CustomerMenuComponent,
  CouponsPipeByMaxPricePipe,
  PurchasesPipeByMaxSumPipe,
  PurchasesPipeByMinSumPipe,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule, 
    RoutingModule,
    HttpClientModule,
  ],
  providers: [
    UserService,
    CouponService,
    PurchaseService,
    CustomerService,
    { provide: HTTP_INTERCEPTORS, useClass: AuthenticationInterceptor, multi: true }
  ],
  bootstrap: [LayoutComponent]
})
export class AppModule { }
