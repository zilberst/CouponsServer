import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from '../components/login/login.component';
import { RegisterComponent } from '../components/register/register.component';
import { CustomerHomeComponent } from '../components/customer/customer-home/customer.component';
import { CustomerPurchasesComponent } from '../components/customer/customer-purchases/customer-purchases.component';
import { AvailableCouponsComponent } from '../components/customer/available-coupons/available-coupons.component';
import { CustomerDetailsComponent } from '../components/customer/customer-details/customer-details.component';
import { CustomerMenuComponent } from '../components/menu/customer-menu/customer-menu.component';

const routes: Routes = [
  { path: "home", component: LoginComponent },
  { path: "customer",
    children:[
      { path: "", component: CustomerHomeComponent },
      { path: "", component: CustomerMenuComponent, outlet: "menu" },
      { path: "myPurchases", component: CustomerPurchasesComponent },
      { path: "availableCoupons", component: AvailableCouponsComponent },
      { path: "myDetails", component: CustomerDetailsComponent },
    ]
   },
  { path: "register", component: RegisterComponent },
  { path: "", redirectTo: "home", pathMatch: "full" }, // pathMatch = התאמת המחרוזת הריקה לכלל הנתיב
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ]
})
export class RoutingModule { }
